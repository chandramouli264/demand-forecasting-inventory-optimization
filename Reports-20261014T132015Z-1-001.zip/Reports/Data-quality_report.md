# Week 1 Data Quality Report

## 1. Objective

To assess the completeness, consistency, uniqueness, date coverage, sales behavior, and price coverage of the M5 Forecasting dataset before further analysis.

## 2. Dataset Validation Results

| Check | Result | Status |
|---|---|---|
| Missing values in sales dataset | 0 | Pass |
| Missing values in calendar | Present only in event-related columns | Documented |
| Missing values in price dataset | 0 | Pass |
| Duplicate sales rows | 0 | Pass |
| Duplicate sales IDs | 0 | Pass |
| Duplicate calendar dates | 0 | Pass |
| Duplicate price keys | 0 | Pass |
| Negative sales quantities | 0 | Pass |
| Missing daily sales values | 0 | Pass |
| Calendar date coverage | 2011-01-29 to 2016-06-19 | Documented |
| Calendar dates missing within the range | 0 | Pass |
| Unique products | 3,049 | Documented |
| Unique stores | 10 | Documented |
| Product-store series | 30,490 | Documented |
| Zero or negative prices | 0 | Pass |
| Sales-day identifiers without calendar mapping | 0 | Pass |

## 3. Price Coverage Issue

The sales data was reshaped to product-store-day records and matched with calendar weeks and selling prices.

- Product-store-week combinations checked: 8,354,260
- Combinations without a matching price record: 1,757,059
- Percentage without a matching price: approximately 21.03%

The missing price matches are concentrated particularly in the early weeks. The absence of a price record does not necessarily mean the price was zero or that the product was unavailable.

**Recommended action:** Preserve missing price values as missing until their cause can be investigated. Do not fill them with arbitrary values.

## 4. Zero-Sales Analysis

- Total zero-sales observations: 39,777,094
- Average zero-sales days per product-store series: approximately 1,304.59
- Maximum zero-sales days for a series: 1,906

Zero sales may represent days without demand, intermittent purchasing, product availability issues, or other operational factors. The available data does not establish which explanation applies to each observation.

## 5. Limitations and Risks

1. Inventory-on-hand data is not available in the three selected files.
2. Explicit stockout indicators are not available.
3. Missing price matches may affect later analyses involving price and demand.
4. Zero sales cannot be assumed to represent zero underlying demand.
5. The available data does not provide a complete transaction-level record of returns.

## 6. Conclusion

The three datasets passed the principal checks for duplicate records, sales missingness, date mapping, and invalid negative quantities or prices. The main issue identified is incomplete price matching for approximately 21.03% of derived product-store-week combinations. This limitation must be considered in subsequent analysis.

**Report status:** Week 1 data-quality assessment completed.