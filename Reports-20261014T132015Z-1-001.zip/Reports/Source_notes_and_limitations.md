# Data Source Notes — M5 Forecasting

## 1. Source

**Dataset:** M5 Forecasting Accuracy

**Platform:** Kaggle

**Competition page:** https://www.kaggle.com/competitions/m5-forecasting-accuracy/data

**Files used:**
- `sales_train_validation.csv`
- `calendar.csv`
- `sell_prices.csv`

The files were downloaded from the competition's data page and used for the Week 1 data collection, validation, and exploratory analysis tasks.

## 2. Data Coverage

The selected sales history covers 2011-01-29 through 2016-04-24, represented by 1,913 daily sales columns. The calendar extends through 2016-06-19, providing 1,969 dates.

The data covers:
- 3,049 products
- 10 stores
- 3 product categories: FOODS, HOBBIES, and HOUSEHOLD
- Daily unit sales
- Weekly selling prices
- Calendar, event, and SNAP-related information

## 3. Known Limitations

1. **Inventory availability:** The selected files do not provide complete inventory-on-hand quantities.
2. **Stockouts:** Explicit stockout records are unavailable, so lost demand cannot be directly identified.
3. **Returns:** A separate, complete transaction-level returns ledger is not included in the selected files.
4. **Supplier information:** Supplier lead times and replenishment constraints are not provided.
5. **Price matching:** Approximately 21.03% of derived product-store-week combinations have no matching price record.
6. **Event information:** Some calendar event fields are blank because corresponding event information is unavailable.
7. **Demand interpretation:** Recorded sales are not necessarily equal to unconstrained customer demand when products may have been unavailable.

## 4. Handling Principles

- Keep original downloaded CSV files unchanged.
- Do not replace missing prices with arbitrary values.
- Do not interpret every zero-sales observation as a stockout.
- Document unavailable variables rather than fabricating them.
- Record any future cleaning or transformations so they can be reproduced.

## 5. Week 1 Status

The selected data sources have been loaded, validated, and explored. Initial data-quality issues and limitations have been documented.