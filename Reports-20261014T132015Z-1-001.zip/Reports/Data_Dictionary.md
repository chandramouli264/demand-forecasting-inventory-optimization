# Data Dictionary — M5 Forecasting Dataset

## 1. Dataset Overview

The project uses three CSV files from the Kaggle M5 Forecasting Accuracy competition.

| File | Purpose | Observed structure |
|---|---|---|
| `sales_train_validation.csv` | Historical daily unit sales for each product-store series | 30,490 rows; 1,913 daily sales columns |
| `calendar.csv` | Maps daily identifiers to dates and provides calendar/event information | 1,969 dates |
| `sell_prices.csv` | Weekly selling prices for products at individual stores | Price records keyed by product, store, and week |

## 2. Sales Dataset: `sales_train_validation.csv`

| Column | Description |
|---|---|
| `id` | Unique identifier for a product-store sales series |
| `item_id` | Product identifier |
| `dept_id` | Department identifier |
| `cat_id` | Product category identifier |
| `store_id` | Store identifier |
| `state_id` | State associated with the store |
| `d_1` to `d_1913` | Daily unit sales represented by day identifiers |

The daily sales columns contain observed unit sales. A value of zero indicates no recorded sales for that product-store-day; it does not by itself prove a stockout.

## 3. Calendar Dataset: `calendar.csv`

| Column | Description |
|---|---|
| `date` | Calendar date corresponding to a day identifier |
| `wm_yr_wk` | Walmart year-week identifier used to join weekly prices |
| `weekday` | Name of the weekday |
| `wday` | Numeric weekday identifier |
| `month` | Calendar month |
| `year` | Calendar year |
| `d` | Daily identifier matching the sales columns |
| `event_name_1`, `event_type_1` | Primary event name and type, where available |
| `event_name_2`, `event_type_2` | Secondary event name and type, where available |
| `snap_CA`, `snap_TX`, `snap_WI` | SNAP-related indicators for California, Texas, and Wisconsin |

Event fields can be blank when no corresponding event is recorded. These blanks should not automatically be treated as data errors.

## 4. Price Dataset: `sell_prices.csv`

| Column | Description |
|---|---|
| `store_id` | Store identifier |
| `item_id` | Product identifier |
| `wm_yr_wk` | Year-week identifier |
| `sell_price` | Selling price for the product at the store during that week |

The expected key for a price record is (`store_id`, `item_id`, `wm_yr_wk`).

## 5. Important Notes

- The sales data contains 30,490 product-store series across 10 stores and 3 categories.
- Sales are recorded daily, whereas prices are recorded weekly.
- Price availability is incomplete for some product-store-week combinations derived from the sales history.
- The available files do not provide complete inventory-on-hand quantities, explicit stockout flags, or supplier lead times.